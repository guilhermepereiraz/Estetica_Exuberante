const carrosselItens = document.querySelector('.carrossel-itens');
const carrosselItensArray = Array.from(carrosselItens.children);
const carrosselItemLargura = carrosselItensArray[0].offsetWidth;
let indiceAtual = 0;

document.querySelector('.carrossel-anterior').addEventListener('click', () => {
    indiceAtual--;
    if (indiceAtual < 0) {
        indiceAtual = carrosselItensArray.length - 4;
    }
    atualizarCarrossel();
});

document.querySelector('.carrossel-proximo').addEventListener('click', () => {
    indiceAtual++;
    if (indiceAtual > carrosselItensArray.length - 4) {
        indiceAtual = 0;
    }
    atualizarCarrossel();
});

function atualizarCarrossel() {
    carrosselItens.style.transform = `translateX(-${indiceAtual * carrosselItemLargura}px)`;
}